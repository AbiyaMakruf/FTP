*Create folder Download, Upload, Database

1. Jalankan program server.py
2. Jalankan program client.py